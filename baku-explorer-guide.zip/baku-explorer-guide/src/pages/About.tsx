
import React from 'react';
import Header from '@/components/Header';
import BottomNav from '@/components/Navigation/BottomNav';
import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const About = () => {
  return (
    <div className="pb-16">
      <Header title="About Baku" subtitle="The Pearl of the Caspian Sea" />
      
      <div className="p-4">
        <div className="relative h-48 mb-6 rounded-xl overflow-hidden">
          <img 
            src="/attached_assets/Baku bulvari.jpg" 
            alt="Baku Boulevard"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
          <h1 className="absolute bottom-4 left-4 text-2xl font-bold text-white">
            Welcome to Baku
          </h1>
        </div>

        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="culture">Culture</TabsTrigger>
            <TabsTrigger value="landmarks">Landmarks</TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <Card className="p-4 mb-4">
              <div className="flex items-center gap-4 mb-4">
                <img 
                  src="/attached_assets/c2.jpg" 
                  alt="Modern Baku"
                  className="w-24 h-24 rounded-lg object-cover"
                />
                <div>
                  <h2 className="text-xl font-bold text-baku-primary">Modern Metropolis</h2>
                  <p className="text-gray-600">Population: 2.3 million+</p>
                  <p className="text-gray-600">Area: 2,140 km²</p>
                </div>
              </div>
              <p className="text-gray-700">
                Baku, Azerbaijan's capital, combines ancient heritage with ultramodern development. As the largest city on the Caspian Sea, it serves as the country's primary economic and cultural hub.
              </p>
            </Card>

            <Card className="p-4">
              <h2 className="text-xl font-bold mb-2 text-baku-primary">Climate & Geography</h2>
              <ul className="list-disc list-inside space-y-2 text-gray-700">
                <li>Semi-arid climate with warm summers</li>
                <li>Located 28 meters below sea level</li>
                <li>Known for strong north winds ("Khazri")</li>
                <li>Average temperature: 14.2°C (57.6°F)</li>
              </ul>
            </Card>
          </TabsContent>

          <TabsContent value="culture">
            <div className="grid gap-4">
              <Card className="p-4">
                <img 
                  src="/attached_assets/shirvan5.jpeg" 
                  alt="Cultural Heritage"
                  className="w-full h-48 rounded-lg object-cover mb-4"
                />
                <h2 className="text-xl font-bold mb-2 text-baku-primary">Rich Heritage</h2>
                <p className="text-gray-700">
                  Baku's culture is a fascinating blend of East and West, combining ancient Islamic traditions with modern European influences. The city is renowned for its carpet weaving, mugham music, and traditional dances.
                </p>
              </Card>

              <Card className="p-4">
                <h2 className="text-xl font-bold mb-2 text-baku-primary">Cuisine</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <img 
                    src="/attached_assets/f10.jpg" 
                    alt="Traditional Azerbaijani Food"
                    className="w-full h-48 rounded-lg object-cover"
                  />
                  <img 
                    src="/attached_assets/EP03535-003-e1662994724915-1920x0-c-default.webp" 
                    alt="Baku Restaurant"
                    className="w-full h-48 rounded-lg object-cover"
                  />
                </div>
                <div className="space-y-4">
                  <div>
                    <h3 className="font-semibold text-baku-primary">Traditional Dishes</h3>
                    <ul className="list-disc list-inside text-gray-700 mt-2">
                      <li>Plov (Pilaf) - Azerbaijan's national dish made with saffron-scented rice</li>
                      <li>Dolma - Stuffed grape leaves with minced meat and aromatic herbs</li>
                      <li>Kebabs - Various grilled meat dishes including lula, tika, and sturgeon</li>
                      <li>Qutab - Thin flatbreads filled with meat, cheese, or spinach</li>
                    </ul>
                  </div>
                  
                  <div>
                    <h3 className="font-semibold text-baku-primary">Local Specialties</h3>
                    <ul className="list-disc list-inside text-gray-700 mt-2">
                      <li>Black Caviar - Premium Caspian Sea delicacy</li>
                      <li>Pakhlava - Sweet pastry made with nuts and honey</li>
                      <li>Sheki Halva - Famous dessert from the city of Sheki</li>
                      <li>Tandir bread - Traditional bread baked in clay ovens</li>
                    </ul>
                  </div>

                  <div>
                    <h3 className="font-semibold text-baku-primary">Dining Culture</h3>
                    <p className="text-gray-700 mt-2">
                      Azerbaijani dining is a social experience centered around sharing and hospitality. Traditional restaurants (restoran) and tea houses (çayxana) offer authentic local experiences. Most meals are served with fresh herbs, local cheese, and traditional bread.
                    </p>
                  </div>
                </div>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="landmarks">
            <div className="grid gap-4">
              <Card className="p-4">
                <img 
                  src="/attached_assets/ZHA_Heydar_Aliyev_Centre_Baku_HuftonCrow_032.jpg" 
                  alt="Heydar Aliyev Center"
                  className="w-full h-48 rounded-lg object-cover mb-4"
                />
                <h2 className="text-xl font-bold mb-2 text-baku-primary">Modern Architecture</h2>
                <p className="text-gray-700">
                  The city features stunning modern architecture including the iconic Flame Towers and the award-winning Heydar Aliyev Center designed by Zaha Hadid.
                </p>
              </Card>

              <Card className="p-4">
                <img 
                  src="/attached_assets/b8c99d401b90bd06021c122b4346c8f7-maiden-s-tower.jpg" 
                  alt="Maiden Tower"
                  className="w-full h-48 rounded-lg object-cover mb-4"
                />
                <h2 className="text-xl font-bold mb-2 text-baku-primary">Historical Sites</h2>
                <ul className="list-disc list-inside space-y-2 text-gray-700">
                  <li>Maiden Tower (12th century)</li>
                  <li>Palace of the Shirvanshahs</li>
                  <li>Old City (UNESCO World Heritage site)</li>
                  <li>Ateshgah Fire Temple</li>
                </ul>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      <BottomNav activeTab="about" />
    </div>
  );
};

export default About;
